export const CMS_NAME = 'ParsaFiroozi';
export const CMS_URL = 'https://parsa-firoozi.ir.';
