export const FilterActionTypes =
{
    SET_ACTIVE_FILTER: 'SET_ACTIVE_FILTER'
};
