export const PortfolioActionTypes =
    {
        SET_IMAGE_PORTFOLIO: 'SET_IMAGE_PORTFOLIO',
        SET_TAG_PORTFOLIO: 'SET_TAG_PORTFOLIO'
    };
