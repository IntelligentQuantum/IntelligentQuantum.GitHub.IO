export const NavbarActionTypes =
{
    SET_OPEN_NAVBAR: 'SET_OPEN_NAVBAR'
};
