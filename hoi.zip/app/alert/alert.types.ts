export const AlertActionTypes =
    {
        SET_ACTIVE_ALERT: 'SET_ACTIVE_ALERT'
    };
