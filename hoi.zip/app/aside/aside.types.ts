export const AsideActionTypes =
{
    SET_OPEN_ASIDE: 'SET_OPEN_ASIDE'
};
