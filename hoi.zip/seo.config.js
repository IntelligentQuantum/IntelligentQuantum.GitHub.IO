export default
{
    openGraph:
        {
            type: 'website',
            locale: 'en_IE',
            url: 'https://parsa-firoozi.ir/',
            site_name: 'Parsa Firoozi'
        },
    twitter:
        {
            handle: '@handle',
            site: '@im-parsa',
            cardType: 'summary_large_image'
        }
};
