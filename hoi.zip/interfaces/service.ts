export interface IService
{
    id: number,
    title: string,
    description: string
}
