export interface IPlan
{
    id: number,
    title: string,
    price: string,
    a: string,
    b: string,
    c: string
}
