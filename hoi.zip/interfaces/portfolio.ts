export interface IPortfolio
{
    id: number,
    title: string,
    tag: string,
    description: string,
    link: string,
    image: string
}
