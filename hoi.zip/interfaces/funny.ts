export interface IFunny
{
    id: number,
    title: string,
    type: string,
    description: string
}
