export interface IFingerprint
{
    ip: string,
    fingerprint: object,
    createdAt: Date
}
