import type { IContent } from './content';

export interface IData
{
    en: IContent,
    de: IContent,
    fa: IContent
}
