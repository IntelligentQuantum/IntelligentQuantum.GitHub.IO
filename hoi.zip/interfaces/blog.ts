export interface IBlog
{
    id: number,
    name: string,
    description: string,
    created_at: string,
    source: string,
    image: string,
    category: string,
    content: string
}
